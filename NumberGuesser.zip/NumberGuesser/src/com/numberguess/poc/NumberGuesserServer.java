/**
 * Copyright (c) 2016
 * All rights reserved.
 * These materials are confidential and proprietary to the author.
 * and no part of these materials should be reproduced, published in
 * any form by any means, electronic or mechanical including photocopy
 * or any information storage or retrieval system nor should the
 * materials be disclosed to third parties without the express written
 * authorization of the Author
 *
 * @author Naveen
 */
package com.numberguess.poc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

/**
 *
 * @author NK38103
 */
public class NumberGuesserServer {

	/**
	 * An logger Object defined to add the logs for this NumberGuesserClient
	 * class
	 */
	private final static Logger LOGGER = Logger
			.getLogger(NumberGuesserServer.class);

	/**
	 * Reader to read user inputs
	 */
	private BufferedReader bufferedReader = null;

	/* To capture number of attempts */
	private int totalAttempts = 0;

	/**
	 * @return the totalAttempts
	 */
	public int getTotalAttempts() {
		return totalAttempts;
	}

	/**
	 * @param totalAttempts
	 *            the totalAttempts to set
	 */
	private void setTotalAttempts(int totalAttempts) {
		this.totalAttempts = totalAttempts;
	}

	/**
	 * the method that tries to 'guess' the number based on the end user entries
	 * ('HIGHER','LOWER' ,'YES')
	 * 
	 * @param minRange
	 *            an minimum range Number
	 * @param maxRange
	 *            an maximum range Number
	 * @throws IOException
	 *             an exception is re thrown
	 */
	public void guessNumber(int minRange, int maxRange) throws IOException {

		// Infinitely loops till it find the right Number choice
		while (true) {
			int guessNo = (minRange + maxRange) / 2;

			setTotalAttempts(getTotalAttempts() + 1);
			totalAttempts++;
			// prompting the End User to feed the data
			LOGGER.info("Does this Number is your choice -- " + guessNo
					+ "? (Please answer with HIGHER, LOWER, or YES):");

			String userResponse = bufferedReader.readLine();

			if (NumberGuesserConstants.USER_INPUT_HIGHER.equals(userResponse)) {
				minRange = guessNo + 1;

			} else if (NumberGuesserConstants.USER_INPUT_LOWER
					.equals(userResponse)) {
				maxRange = guessNo - 1;
			} else if (NumberGuesserConstants.USER_INPUT_YES
					.equals(userResponse)) {
				LOGGER.info("Success !!!  Total Number of attempts Made - "
						+ getTotalAttempts());
				break;
			} else {
				throw new IllegalStateException(
						"Wrong Data .Please enter proper Input ");
			}
		}
	}

	/**
	 * Closes the buffered reader
	 */
	public void closeReader() {
		try {
			bufferedReader.close();
		} catch (Exception exception) {
			LOGGER.error("Sorry, something wrong! : ", exception);
		}
	}

	/**
	 * An BufferReader object is created along with the constructor to read data
	 * from command line
	 */
	public NumberGuesserServer() {
		bufferedReader = new BufferedReader(new InputStreamReader(System.in));

	}

}
