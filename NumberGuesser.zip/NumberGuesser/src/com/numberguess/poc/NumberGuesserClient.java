/**
 * Copyright (c) 2016
 * All rights reserved.
 * These materials are confidential and proprietary to the author.
 * and no part of these materials should be reproduced, published in
 * any form by any means, electronic or mechanical including photocopy
 * or any information storage or retrieval system nor should the
 * materials be disclosed to third parties without the express written
 * authorization of the Author
 *
 * @author Naveen
 */
package com.numberguess.poc;

import java.io.IOException;
import org.apache.log4j.Logger;

/**
 * The Number Guesser Game program implements an application that finds the end
 * user guessed Number based on the series of queries.This Class is an
 * BootStartup Class
 *
 * @author Naveen
 * @version 1.0
 * @since 2016-03-14
 */
public final class NumberGuesserClient {

	/**
	 * An logger Object defined to add the logs for this NumberGuesserClient
	 * class
	 */
	private final static Logger LOGGER = Logger
			.getLogger(NumberGuesserClient.class);

	private NumberGuesserClient() {

	}

	/**
	 * Main method to start the Number Guesser Game program
	 * 
	 * @param args
	 */
	public static void main(final String[] args) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("main::  START ");
		}

		final NumberGuesserServer numGuesser = new NumberGuesserServer();

		// NOTE : Assuming we are setting the log level in Info Mode
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Please Select the Number With In the Range : "
					+ NumberGuesserConstants.MIN_RANGE_VALUE + "  and "
					+ NumberGuesserConstants.MAX_RANGE_VALUE);
		}

		try {

			numGuesser.guessNumber(NumberGuesserConstants.MIN_RANGE_VALUE,
					NumberGuesserConstants.MAX_RANGE_VALUE);
		} catch (IOException exception) {
			LOGGER.error("Sorry, something wrong! : ", exception);
		} finally {
			numGuesser.closeReader();
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("main::  END ");
		}
	}

}
