/**
 * Copyright (c) 2016
 * All rights reserved.
 * These materials are confidential and proprietary to the author.
 * and no part of these materials should be reproduced, published in
 * any form by any means, electronic or mechanical including photocopy
 * or any information storage or retrieval system nor should the
 * materials be disclosed to third parties without the express written
 * authorization of the Author
 *
 * @author Naveen
 */
package com.numberguess.poc;

/**
 *
 * @author NK38103
 */
public final class NumberGuesserConstants {
	
	
	/** Minimimum Range Value to be considered for Input */
	public static final int MIN_RANGE_VALUE = 0;

	/** Maximum Range Value to be considered for Input */
	public static final int MAX_RANGE_VALUE = 100;

	/** An User input entry value for Higher Range */
	public static final String USER_INPUT_HIGHER = "HIGHER";

	/** An User input entry value for Lower Range */
	public static final String USER_INPUT_LOWER = "LOWER";

	/** An User input entry value for Matching Value */
	public static final String USER_INPUT_YES = "YES";

	
	private NumberGuesserConstants() {
		// To Block  the instance level object creation of this class
	}

}
