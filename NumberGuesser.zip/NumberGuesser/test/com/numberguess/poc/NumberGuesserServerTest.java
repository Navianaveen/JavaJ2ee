/**
 * Copyright (c) 2016
 * All rights reserved.
 * These materials are confidential and proprietary to the author.
 * and no part of these materials should be reproduced, published in
 * any form by any means, electronic or mechanical including photocopy
 * or any information storage or retrieval system nor should the
 * materials be disclosed to third parties without the express written
 * authorization of the Author
 *
 * @author Naveen
 */
package com.numberguess.poc;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author NK38103
 *
 */
public class NumberGuesserServerTest {

	/**
	 * An instance reference defined for testing the code
	 */
	NumberGuesserServer noGuessServer = null;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		noGuessServer = new NumberGuesserServer();
	}

	/**
	 * An unit testing that validates the successfull attempt of this unit code
	 */
	@Test
	public void testguessNumberOnSuccessfullAttempts() throws IOException {

		// User Guess No is 65, per Algorithm the no of attempts should be only
		// 5
		// i.e in 5th Attempt , we should get the expected results
		noGuessServer.guessNumber(NumberGuesserConstants.MIN_RANGE_VALUE, NumberGuesserConstants.MAX_RANGE_VALUE);
		assertEquals(5, noGuessServer.getTotalAttempts());
	}

	/**
	 * An unit testing that validates the failure case of this unit code
	 */
	@Test(expected = IllegalStateException.class)
	public void testguessNumberthrowsIllegalException() throws IOException {

		// User Guess No is 65, but end user wrongly feeds the inputs.
		// it should throw Illegalstate exception
		// Lets say rather than passing "HIGHER","LOWER","YES" , the
		// end user is passing wrong data like "TEST".
		noGuessServer.guessNumber(NumberGuesserConstants.MIN_RANGE_VALUE, NumberGuesserConstants.MAX_RANGE_VALUE);
		assertEquals(6, noGuessServer.getTotalAttempts());
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

}
